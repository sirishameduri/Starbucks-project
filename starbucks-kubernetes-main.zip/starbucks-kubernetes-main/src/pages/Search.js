import React from 'react'

const Search = () => {
  return (
    <div>Search</div>
  )
}

export default Search